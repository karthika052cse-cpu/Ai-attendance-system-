# AI-Based Attendance System – Demo

This package contains a browser-based demonstration for the college Skill Development Cell project.

## Run
1. Extract the ZIP.
2. Open `index.html` in Chrome/Edge.
3. Click **Start Camera** if you want to demonstrate camera access.
4. Click **Simulate Face Recognition** to demonstrate student identification and attendance recording.
5. The attendance table is stored only in the browser's local storage.

## Important
This is a demonstration prototype. The recognition button simulates an AI recognition result; it does not claim to perform real biometric face recognition.

For the final project, replace the simulation module with a properly consented face-recognition implementation and secure database.
